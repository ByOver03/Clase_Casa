text = " bIENVENIDOS A odoo "
text = text.strip().lower().capitalize().replace("odoo", "Odoo")
print(text)